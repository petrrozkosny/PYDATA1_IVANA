# Buňka pro body 10-14
# Buňka pro body 1-5
import numpy as np
import pandas as pd

url = 'https://raw.githubusercontent.com/petrrozkosny/pydata/main/pydata_data.csv'
df = pd.read_csv(url,delimiter=';')
df['DATE'] = pd.to_datetime(df['DATE'])
df['YEAR'] = df['DATE'].dt.year
df['MONTH'] = df['DATE'].dt.month
print(df.dtypes)
# Buňka pro body 6-9	¨
df_filtrovano = df.loc[df['YEAR']>=2015]
df_filtrovano = df_filtrovano[['DATE','YEAR','MONTH','PRCP']]
df_info = df_filtrovano.shape
print(df_filtrovano.head())

df_agregovano = df_filtrovano.groupby(by='YEAR')['PRCP'].sum()
df_agregovano = df_agregovano.sort_index(ascending=True)

# varianta 1
max_srazky = df_agregovano.max()
min_srazky = df_agregovano.min()
df_agregovano_rok_max_srazky = df_agregovano.loc[df_agregovano == max_srazky].index.values
df_agregovano_rok_min_srazky = df_agregovano.loc[df_agregovano == min_srazky].index.values
print(f'maximalni srazky: {max_srazky}')
print(f'rok s nejvetsim mnozstvim srazek: {df_agregovano_rok_max_srazky}')
print(f'minimalni srazky: {min_srazky}')
print(f'rok s nejmensim mnozstvim srazek: {df_agregovano_rok_min_srazky}')